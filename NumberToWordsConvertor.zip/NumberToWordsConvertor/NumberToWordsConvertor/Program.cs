﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordsConvertor
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Please enter a Number to convert to words");

                string number = Console.ReadLine();

                long num = 0;

                if (!long.TryParse(number, out num))
                {
                    Console.WriteLine("Please enter Number");
                    number = Console.ReadLine();
                }


                if (number.Length > 9)
                {
                    Console.WriteLine(" \n Number is greater than 999,999,999");
                }
                else
                {

                    if (number == "0")
                    {
                        Console.WriteLine(" \n Zero ");
                    }
                    else
                    {
                        Console.WriteLine(" \n{0}", Convertnumbertowords(number));
                    }
                }
                Console.ReadKey();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        private static String Checkones(String Number)
        {
            int _Number = Convert.ToInt32(Number);
            String name = "";
            switch (_Number)
            {

                case 1:
                    name = "one";
                    break;
                case 2:
                    name = "two";
                    break;
                case 3:
                    name = "three";
                    break;
                case 4:
                    name = "four";
                    break;
                case 5:
                    name = "five";
                    break;
                case 6:
                    name = "six";
                    break;
                case 7:
                    name = "seven";
                    break;
                case 8:
                    name = "eight";
                    break;
                case 9:
                    name = "nine";
                    break;
            }
            return name;
        }

        private static String Checktens(String Number)
        {
            int _Number = Convert.ToInt32(Number);
            String name = null;
            switch (_Number)
            {
                case 10:
                    name = "ten";
                    break;
                case 11:
                    name = "eleven";
                    break;
                case 12:
                    name = "twelve";
                    break;
                case 13:
                    name = "thirteen";
                    break;
                case 14:
                    name = "fourteen";
                    break;
                case 15:
                    name = "fifteen";
                    break;
                case 16:
                    name = "sixteen";
                    break;
                case 17:
                    name = "seventeen";
                    break;
                case 18:
                    name = "eighteen";
                    break;
                case 19:
                    name = "nineteen";
                    break;
                case 20:
                    name = "twenty";
                    break;
                case 30:
                    name = "thirty";
                    break;
                case 40:
                    name = "forty";
                    break;
                case 50:
                    name = "fifty";
                    break;
                case 60:
                    name = "sixty";
                    break;
                case 70:
                    name = "seventy";
                    break;
                case 80:
                    name = "eighty";
                    break;
                case 90:
                    name = "ninety";
                    break;
                default:
                    if (_Number > 0)
                    {
                        name = Checktens(Number.Substring(0, 1) + "0") + " " + Checkones(Number.Substring(1));
                    }
                    break;
            }
            return name;
        }

        private static String Convertnumbertowords(String Number)
        {
            string word = "";
            try
            {
                bool isDone = false;
                long inum = (Convert.ToInt64(Number));

                if (inum > 0)
                {
                    int numDigits = Number.Length;
                    int pos = 0;
                    String place = "";
                    switch (numDigits)
                    {
                        case 1://ones

                            word = Checkones(Number);
                            isDone = true;
                            break;
                        case 2://tens 
                            word = Checktens(Number);
                            isDone = true;
                            break;
                        case 3://hundreds 
                            pos = (numDigits % 3) + 1;
                            place = " hundred and ";
                            break;
                        case 4://thousands 
                        case 5:
                        case 6:
                            pos = (numDigits % 4) + 1;
                            place = " thousand ";
                            break;
                        case 7://millions 
                        case 8:
                        case 9:
                            pos = (numDigits % 7) + 1;
                            place = " million ";
                            break;
                        case 10://Billions 
                        case 11:
                        case 12:

                            pos = (numDigits % 10) + 1;
                            place = " billion ";
                            break;
                        default:
                            isDone = true;
                            break;
                    }
                    if (!isDone)
                    {
                        if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                        {
                            try
                            {
                                word = Convertnumbertowords(Number.Substring(0, pos)) + place + Convertnumbertowords(Number.Substring(pos));
                            }
                            catch { }
                        }
                        else
                        {
                            word = Convertnumbertowords(Number.Substring(0, pos)) + Convertnumbertowords(Number.Substring(pos));
                        }


                    }

                    if (word.Trim().Equals(place.Trim())) word = "";
                }
            }
            catch (Exception ex) { throw ex; }

            return String.Format("{0}", word.Trim());
        }

    }
}
