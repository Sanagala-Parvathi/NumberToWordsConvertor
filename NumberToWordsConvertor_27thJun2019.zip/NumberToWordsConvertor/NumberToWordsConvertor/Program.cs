﻿using System;

namespace NumberToWordsConvertor
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Please enter a Number to convert to words");

                string number = Console.ReadLine();

                long num = 0;

                // Validating that the entered value is number or not
                if (!long.TryParse(number, out num))
                {
                    Console.WriteLine("Please enter Number");
                    number = Console.ReadLine();
                }

                
                if (number.Length > 9) // Validating that the entered value is greater than 999,999,999 or not
                {
                    Console.WriteLine(" \n Number is greater than 999,999,999");
                }
                else
                {
                    if (Convert.ToInt32(number) == 0) // Validating that the entered value is zero or not
                    {
                        Console.WriteLine(" \n Zero ");
                    }
                    else if (Convert.ToInt32(number) < 0) // Validating that the entered value is negative number or not
                    {
                        Console.WriteLine(" \n Its a negetive number");
                    }
                    else
                    {
                        Console.WriteLine(" \n{0} - {1}", number, Convertnumbertowords(number));
                    }
                }
                Console.WriteLine("\n ========= Please press any key to Exit ===========");
                Console.ReadKey(true);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
#region GenerateOnesPlaceword
        private static String Checkones(String number)
        {
            int onesPlaceNumber = Convert.ToInt32(number);

            // Initialize as an empty string.
            String onesPlaceWord = System.String.Empty;

            try
            {
                // Switch case to check the number to generate word for ones place 
                switch (onesPlaceNumber)
            {

                case 1:
                    onesPlaceWord = "one";
                    break;
                case 2:
                    onesPlaceWord = "two";
                    break;
                case 3:
                    onesPlaceWord = "three";
                    break;
                case 4:
                    onesPlaceWord = "four";
                    break;
                case 5:
                    onesPlaceWord = "five";
                    break;
                case 6:
                    onesPlaceWord = "six";
                    break;
                case 7:
                    onesPlaceWord = "seven";
                    break;
                case 8:
                    onesPlaceWord = "eight";
                    break;
                case 9:
                    onesPlaceWord = "nine";
                    break;
            }
                return onesPlaceWord;
            }
            catch (Exception) { throw; }
           
        }
#endregion
#region GenerateTenthPlaceword
        private static String Checktens(String numberInTenthPlace)
        {
            int tenthPlaceNumber = Convert.ToInt32(numberInTenthPlace);

            String tenthPlaceWord = null;

            try
            {
                // Switch case to check the number to generate word for tenth place 
                switch (tenthPlaceNumber)
                {
                    case 10:
                        tenthPlaceWord = "ten";
                        break;
                    case 11:
                        tenthPlaceWord = "eleven";
                        break;
                    case 12:
                        tenthPlaceWord = "twelve";
                        break;
                    case 13:
                        tenthPlaceWord = "thirteen";
                        break;
                    case 14:
                        tenthPlaceWord = "fourteen";
                        break;
                    case 15:
                        tenthPlaceWord = "fifteen";
                        break;
                    case 16:
                        tenthPlaceWord = "sixteen";
                        break;
                    case 17:
                        tenthPlaceWord = "seventeen";
                        break;
                    case 18:
                        tenthPlaceWord = "eighteen";
                        break;
                    case 19:
                        tenthPlaceWord = "nineteen";
                        break;
                    case 20:
                        tenthPlaceWord = "twenty";
                        break;
                    case 30:
                        tenthPlaceWord = "thirty";
                        break;
                    case 40:
                        tenthPlaceWord = "forty";
                        break;
                    case 50:
                        tenthPlaceWord = "fifty";
                        break;
                    case 60:
                        tenthPlaceWord = "sixty";
                        break;
                    case 70:
                        tenthPlaceWord = "seventy";
                        break;
                    case 80:
                        tenthPlaceWord = "eighty";
                        break;
                    case 90:
                        tenthPlaceWord = "ninety";
                        break;
                    default:
                        if (tenthPlaceNumber > 0)
                        {
                            tenthPlaceWord = Checktens(numberInTenthPlace.Substring(0, 1) + "0") + " " + Checkones(numberInTenthPlace.Substring(1));
                        }
                        break;
                }
                return tenthPlaceWord;
            }
            catch (Exception) { throw; }
            
        }
#endregion
#region Convert Number to words
        private static String Convertnumbertowords(String Number)
        {
            string word = "";
            try
            {
                bool isDone = false;
                long inum = (Convert.ToInt64(Number));

                if (inum > 0)
                {
                    int numDigits = Number.Length;
                    int pos = 0;
                    String place = "";
                    switch (numDigits)
                    {
                        case 1://ones

                            word = Checkones(Number);
                            isDone = true;
                            break;
                        case 2://tens 
                            word = " and " + Checktens(Number);
                            isDone = true;
                            break;
                        case 3://hundreds 
                            pos = (numDigits % 3) + 1;
                            place = " hundred ";
                            break;
                        case 4://thousands 
                        case 5:
                        case 6:
                            pos = (numDigits % 4) + 1;
                            place = " thousand ";
                            break;
                        case 7://millions 
                        case 8:
                        case 9:
                            pos = (numDigits % 7) + 1;
                            place = " million ";
                            break;
                        case 10://Billions 
                        case 11:
                        case 12:

                            pos = (numDigits % 10) + 1;
                            place = " billion ";
                            break;
                        default:
                            isDone = true;
                            break;
                    }
                    if (!isDone)
                    {
                        if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                        {
                            try
                            {
                                word = Convertnumbertowords(Number.Substring(0, pos)) + place + Convertnumbertowords(Number.Substring(pos));
                            }
                            catch { }
                        }
                        else
                        {
                            word = Convertnumbertowords(Number.Substring(0, pos)) + Convertnumbertowords(Number.Substring(pos));
                        }


                    }

                    if (word.Trim().Equals(place.Trim())) word = "";
                }
            }
            catch (Exception) { throw; }

            return String.Format("{0}", word.Trim());
        }
#endregion
    }
}
